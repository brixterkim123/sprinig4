package com.accenture.bars.domain;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.web.servlet.ModelAndView;

public class Billing {
	
	private int billingId;
	private int billingCycle;
	private String billingMonth;
	private double amount;
	private String startDate;
	private  String endDate;
	private String lastEdited;
	
	public Billing() {
		
	}
	
	public Billing(int billingId, int billingCycle, String billingMonth, double amount, String startDate, String endDate, String lastEdited) {
		super();
		this.billingId = billingId;
		this.billingCycle = billingCycle;
		this.billingMonth = billingMonth;
		this.amount = amount;
		this.startDate = startDate;
		this.endDate = endDate;
		this.lastEdited = lastEdited;
	}

	public Billing(String jsonObject) throws JSONException, ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMMdd");
		
		JSONObject accountJson = new JSONObject(jsonObject);
		this.billingId = (int) accountJson.getInt("billingId");
		this.billingCycle = (int) accountJson.getInt("billingCycle");
		this.billingMonth = (String) accountJson.getString("billingMonth");
		this.amount = (double) accountJson.getInt("amount");
		this.startDate = (String) accountJson.getString("startDate");
		this.endDate =  (String) accountJson.getString("endDate");
		this.lastEdited = (String) accountJson.getString("lastEdited");
	}
	
	public void addModelAndView(ModelAndView mv) {
		mv.addObject("billingId", this.billingId);
		mv.addObject("billingCycle", this.billingCycle);
		mv.addObject("billingMonth", this.billingMonth);
		mv.addObject("amount", this.amount);
		mv.addObject("startDate", this.startDate);
		mv.addObject("endDate", this.endDate);
		mv.addObject("lastEdited", this.lastEdited);
	}

	
	public String toJson() throws JSONException {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("billingId", this.billingId);
		jsonObject.put("billingCycle", this.billingCycle);
		jsonObject.put("billingMonth", this.billingMonth);
		jsonObject.put("amount", this.amount);
		jsonObject.put("startDate", this.startDate);
		jsonObject.put("endDate", this.endDate);
		jsonObject.put("lastEdited", this.lastEdited);
		return jsonObject.toString();
	}

	
	
	public int getBillingCycle() {
		return billingCycle;
	}

	public void setBillingCycle(int billingCycle) {
		this.billingCycle = billingCycle;
	}

	public int getBillingId() {
		return billingId;
	}
	public void setBillingId(int billingId) {
		this.billingId = billingId;
	}
	public String getBillingMonth() {
		return billingMonth;
	}
	public void setBillingMonth(String billingMonth) {
		this.billingMonth = billingMonth;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getLastEdited() {
		return lastEdited;
	}
	public void setLastEdited(String lastEdited) {
		this.lastEdited = lastEdited;
	}
	
	

}
