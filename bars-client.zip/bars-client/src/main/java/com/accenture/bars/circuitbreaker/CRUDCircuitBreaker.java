package com.accenture.bars.circuitbreaker;

import java.util.Base64;

import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.UniformInterfaceException;
import com.sun.jersey.api.client.WebResource;

@Service
public class CRUDCircuitBreaker {


	Logger logger = Logger.getLogger(this.getClass());
	
	@HystrixCommand(fallbackMethod = "deleteErrorCustomer")
	public ModelAndView deleteCustomer(@RequestParam("customerId") int customerId) throws JSONException {
		ModelAndView model = new ModelAndView();

				String url = "http://localhost:2000/bars/deleteCustomer/" + customerId;
				Client client = new Client();
				WebResource wr = client.resource(url);
				ClientResponse cr = wr.type(MediaType.APPLICATION_JSON).delete(ClientResponse.class);
				String response = cr.getEntity(String.class);
				JSONObject json = new JSONObject(response);

				if(200 == cr.getStatus()) {
					model.addObject("INFO", json.getString("INFO"));
					model.setViewName("showCustomer");
				} else {
					Logger logger = Logger.getLogger(this.getClass());
					logger.info("Invalid Session");
					model.setViewName("showCustomer");
				}
				
		return model;
	}
	
	@HystrixCommand(fallbackMethod = "deleteErrorBilling")
	public ModelAndView deleteBilling(@RequestParam("billingId") int billingId) throws JSONException {
		ModelAndView model = new ModelAndView();

				String url = "http://localhost:2000/bars/deleteBilling/" + billingId;
				Client client = new Client();
				WebResource wr = client.resource(url);
				ClientResponse cr = wr.type(MediaType.APPLICATION_JSON).delete(ClientResponse.class);
				String response = cr.getEntity(String.class);
				JSONObject json = new JSONObject(response);

				if(200 == cr.getStatus()) {
					model.addObject("INFO", json.getString("INFO"));
					model.setViewName("showCustomer");
				} else {
					Logger logger = Logger.getLogger(this.getClass());
					logger.info("Invalid Session");
					model.setViewName("showBilling");
				}
				
		return model;
	}
	
	@HystrixCommand(fallbackMethod = "deleteErrorAccount")
	public ModelAndView deleteAccount(@RequestParam("accountId") int accountId) throws JSONException {
		ModelAndView model = new ModelAndView();

				String url = "http://localhost:2000/bars/deleteAccount/" + accountId;
				Client client = new Client();
				WebResource wr = client.resource(url);
				ClientResponse cr = wr.type(MediaType.APPLICATION_JSON).delete(ClientResponse.class);
				String response = cr.getEntity(String.class);
				JSONObject json = new JSONObject(response);

				if(200 == cr.getStatus()) {
					model.addObject("INFO", json.getString("INFO"));
					model.setViewName("showCustomer");
				} else {
					Logger logger = Logger.getLogger(this.getClass());
					logger.info("Invalid Session");
					model.setViewName("showAccounts");
				}
				
		return model;
	}

	public ModelAndView deleteErrorCustomer(@RequestParam("customerId") int customerId) throws JSONException {
		ModelAndView model = new ModelAndView();

		model.addObject("ERROR", "Server is not responding...");
		model.setViewName("showCustomer");

		return model;
	}

	public ModelAndView deleteErrorBilling(@RequestParam("billingId") int billingId) throws JSONException {
		ModelAndView model = new ModelAndView();

		model.addObject("ERROR", "Server is not responding...");
		model.setViewName("showBilling");

		return model;
	}
	
	public ModelAndView deleteErrorAccount(@RequestParam("accountId") int accountId) throws JSONException {
		ModelAndView model = new ModelAndView();

		model.addObject("ERROR", "Server is not responding...");
		model.setViewName("showAccounts");

		return model;
	}
}


